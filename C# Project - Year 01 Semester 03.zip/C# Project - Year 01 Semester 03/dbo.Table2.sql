﻿CREATE TABLE [dbo].[tblstudent]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [email] NVARCHAR(50) NULL, 
    [username] NVARCHAR(50) NULL, 
    [password] NVARCHAR(50) NULL
)
